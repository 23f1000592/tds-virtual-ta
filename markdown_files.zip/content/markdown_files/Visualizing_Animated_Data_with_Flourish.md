---
title: "Visualizing Animated Data with Flourish"
original_url: "https://tds.s-anand.net/#/visualizing-animated-data-with-flourish?id=visualizing-animated-data-with-flourish"
downloaded_at: "2025-06-17T10:23:22.051193"
---

[Visualizing Animated Data with Flourish](#/visualizing-animated-data-with-flourish?id=visualizing-animated-data-with-flourish)
-------------------------------------------------------------------------------------------------------------------------------

[![Visualizing animated data with Flourish](https://i.ytimg.com/vi_webp/JrnIu5Bm8i4/sddefault.webp)](https://youtu.be/JrnIu5Bm8i4)

[Previous

Visualizing Animated Data with PowerPoint](#/visualizing-animated-data-with-powerpoint)

[Next

Visualizing Network Data with Kumu](#/visualizing-network-data-with-kumu)