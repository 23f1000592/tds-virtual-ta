---
title: "Spreadsheet: Excel, Google Sheets"
original_url: "https://tds.s-anand.net/#/revealjs"
downloaded_at: "2025-06-17T09:41:21.937267"
---

404 - Not found
===============